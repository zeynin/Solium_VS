This is a solution to the C-Train programming problem from the programming problems document.  The configuration file for the system is located in the config directory and based on the configuration mentioned in the document.

There are two ways to view the outputs for the provided inputs:

1. Use the binary jar in the archive: java -jar solium-ctrain.jar
2. Use the ant target: ant run.assignment

The solution has been tested and built under OS X 10.5.2 using java version 1.5.0_13

The code uses an adjacency list (also known as an incidence list) to represent the C-Train routes as a graph, and uses depth-first graph traversal to find routes.  

Due to the requirements of the assignment, there have been some alterations made to allow for the same stop to repeat within a trip.  This is not particularly elegant.

Also, because there is a potential for infinite loops (for example, the input asking for the route from B to B can run into an infinite loop between stations C and D) there is a simple check for the distance getting over a certain large number that functions as "INFINITY", and if it is exceeded, it will terminate the search.  This is also not particularly elegant.

Note: In the programming problems document, when enumerating the routes created for question 10, the route CDCBC will not occur, since the data does not have a route connection C->B.

The following assumptions regarding routes were made:
- a route cannot have the same station as both origin and destination
- a route cannot have a distance of 0
- there can only be a single route between any two stations

