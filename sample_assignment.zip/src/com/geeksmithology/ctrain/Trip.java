package com.geeksmithology.ctrain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * A Trip represents the stops required to get from one station to another.
 */
public class Trip {
    private final ArrayList<Line> lines;

    /**
     * Creates a new Trip with no stops
     */
    public Trip() {
        lines = new ArrayList<Line>();
    }

    /**
     * Creates a new Trip including the given trip.  Added stops will start from the last station of the given Trip.
     *
     * @param trip A Trip with which to initialize the new trip.
     */
    public Trip(Trip trip) {
        lines = new ArrayList<Line>(trip.lines);
    }

    /**
     * Remove all stations from the end of the trip back to the given station.  If the given station is the last
     * station on the trip, that stop will be removed, but no other instances will be removed.
     *
     * Example:
     *
     * Given a trip A->B->C->E->D->C->E->D->C
     *
     * calling truncate(C) will result in
     *
     * A->B->C->E->D->C
     *
     * Remove all stations from the end of the trip up to, but excluding the provided station.
     *
     * @param station The station from which to truncate.
     */
    public void truncate(Station station) {
        if (lines.get(lines.size() - 1).getDestination().equals(station)) {
            lines.remove(lines.size() - 1);
        }
        for (int i = lines.size() - 1; i >= 0; --i) {
            if (lines.get(i).getDestination().equals(station)) {
                break;
            }
            lines.remove(i);
        }
    }

    /**
     * Add the given Stop to the end of the trip.
     *
     * @param station The station to append to the trip.
     * @param distance The distance to the given station.
     */
    public void addStop(Station station, int distance) {
        lines.add(new Line(station, distance));
    }

    /**
     * This returns the number of stations that will be passed during the trip, including the origin and
     * destination.  If any station is visited more than once, it will be counted for each occurrence.
     *
     * Example:
     * For the route:
     *
     * A->B->C->E->D->C->E
     *
     * Calling stationCount will return 7
     *
     *
     * @return The number of stations visited during the trip.
     */
    public int stationCount() {
        return lines.size();
    }

    /**
     * This returns the number of stops that will be made during the trip.  The origin is not included, only
     * stations for which some distance is travelled.
     *
     * Example:
     * For the route:
     *
     * A->B->C->E->D->C->E
     *
     * calling stopCount will return 6
     *
     * @return The number of stops that will be made during the trip.
     */
    public int stopCount() {
        return lines.size() - 1;
    }

    /**
     * Returns the station that is arrived at when the trip concludes.
     *
     * Example:
     * For the route:
     *
     * A->B->C->E
     *
     * will return E
     *
     * @return The final destination for this trip.
     */
    public Station getLastStation() {
        return lines.get(lines.size() - 1).getDestination();
    }

    /**
     * This counts the distance for every stop on the trip.
     *
     * @return The total distance that will travelled during the trip.
     */
    public int totalDistance() {
        int distance = 0;

        for (Line line: lines) {
            distance += line.getDistance();
        }

        return distance;
    }

    /**
     * Returns a list of all of the stations that will be visited during the trip, in the order they will be visited.
     *
     * @return List of stations to be visited during this trip.
     */
    public List<Station> stations() {
        List<Station> stations = new ArrayList<Station>();

        for (Line line: lines) {
            stations.add(line.getDestination());
        }

        return stations;
    }

    public String toString() {
        return Arrays.deepToString(lines.toArray()) + "[" + totalDistance() + "]";
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Trip trip = (Trip) o;

        if (lines != null ? !lines.equals(trip.lines) : trip.lines != null) return false;

        return true;
    }

    public int hashCode() {
        return (lines != null ? lines.hashCode() : 0);
    }
}
