package com.geeksmithology.ctrain;

/**
 * A Route represents two stations and the track between them.  Routes are one way.
 */
public class Route extends Line {
    private final Station origin;

    /**
     * Create a new one way route.
     *
     * @param origin The station from which the route begins.
     * @param destination The station that ends the rounte; must be different than origin.
     * @param distance The distance between the origin and the destination; cannot be zero.
     * @throws IllegalArgumentException If origin is same as destination, or distance is zero.
     */
    public Route(Station origin, Station destination, int distance) {
        super(destination, distance);

        if (origin.equals(destination)) {
            throw new IllegalArgumentException("Origin and Destination stations cannot be the same.");
        }

        if (distance == 0 || distance > 9) {
            throw new IllegalArgumentException("Distance must be > 0 and < 10.");
        }

        this.origin = origin;
    }

    public Station getOrigin() {
        return origin;
    }

    public String toString() {
        return "(" + origin + ", " + getDestination() + ")[" + getDistance() + "]";
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        Route route = (Route) o;

        if (origin != null ? !origin.equals(route.origin) : route.origin != null) return false;

        return true;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (origin != null ? origin.hashCode() : 0);
        return result;
    }
}
