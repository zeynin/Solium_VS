package com.geeksmithology.ctrain;

/**
 * MatchType contains different criteria to help determine the effect of certain thesholds.
 */
public enum MatchType {
    /** The match, in case of a number, must be equal */
    EXACT,
    /** The match, in the case of a number, must be less than or equal */
    ATLEAST
}
