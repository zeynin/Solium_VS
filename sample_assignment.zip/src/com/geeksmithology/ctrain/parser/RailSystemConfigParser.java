package com.geeksmithology.ctrain.parser;

import com.geeksmithology.ctrain.Route;
import com.geeksmithology.ctrain.Station;
import com.geeksmithology.ctrain.RailSystem;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.StringTokenizer;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.IOException;

/**
 * Class to create a RailSystem based on a text configuration.  The configuration must consist of the following:
 *
 * 1. A header row containing the total number of stations and total number of routes, separated by a comma
 * 2. N rows containing comma delimited lists of routes, in the format AB1, where the first letter is the origin
 * station, the second letter is the destination station, and the number is the distance between the two.  The
 * station names must be a letter from A-M and the number must be between 1 and 9.
 *
 * Example of a configuration.
 * 5,8
 * AB2,AC5,BC8,DA5
 * AE6,DE9,CD3,EB9
 */
public class RailSystemConfigParser {
    private static final int TRIP_DESC_LEN = 3;
    private static final int TRIP_ORIGIN_INDEX = 0;
    private static final int TRIP_DESTINATION_INDEX = 1;
    private static final int TRIP_DISTANCE_INDEX = 2;

    private static final int HDR_STATION_COUNT_GROUP = 1;
    private static final int HDR_ROUTE_COUNT_GROUP = 2;

    // this verifies that a three character string is a valid trip description
    private static final Pattern TRIP_DESC_REGEX = Pattern.compile("[A-M][A-M][1-9]");
    // this validates that a given string is a valid header row.
    private static final Pattern HEADER_REGEX = Pattern.compile("(\\d+)\\s*,\\s*(\\d+)");

    /**
     * Given a string, determines if it is a legal route description and returns the Route if it is.
     *
     * @param routeDescription A string potentially containing a valid route description.
     * @return If the string is a route description, the Route that is described.
     * @throws RailSystemConfigParserException If the description is invalid.
     */
    public Route parseRoute(String routeDescription) throws RailSystemConfigParserException {
        if (routeDescription.length() != TRIP_DESC_LEN || !TRIP_DESC_REGEX.matcher(routeDescription).matches()) {
            throw new RailSystemConfigParserException("Malformed route.  Must be format AB1, was " 
                    + routeDescription + ".");
        }

        if (!TRIP_DESC_REGEX.matcher(routeDescription).matches()) {
            throw new IllegalArgumentException();
        }

        char[] c = routeDescription.toCharArray();
        return new Route(new Station(Character.toString(c[TRIP_ORIGIN_INDEX])),
                new Station(Character.toString(c[TRIP_DESTINATION_INDEX])),
                Character.digit(c[TRIP_DISTANCE_INDEX], 10));
    }

    /**
     * Given a connection to a configuration, builds the described RailSystem.
     *
     * @param config A reader currently pointing to a configuration.
     * @return The RailSystem described by the provided config.
     * @throws IOException If there are any errors reading from the config Reader.
     * @throws RailSystemConfigParserException If any information in the configuration is malformed.
     */
    public RailSystem parseSystemConfiguration(Reader config) throws IOException, RailSystemConfigParserException {
        BufferedReader bin = new BufferedReader(config);
        String header = bin.readLine().trim();

        Matcher headerMatcher = HEADER_REGEX.matcher(header);
        if (!headerMatcher.matches()) {
            throw new RailSystemConfigParserException("Header malformed: must be <station count>,<leg count>, was (" +
                    header + ")");
        }

        // Note: These values are only used for validating the system that is built, they are not necessary
        // for building the system.
        int expectedStationCount = Integer.parseInt(headerMatcher.group(HDR_STATION_COUNT_GROUP));
        int expectedLegCount = Integer.parseInt(headerMatcher.group(HDR_ROUTE_COUNT_GROUP));

        RailSystem railSystem = new RailSystem();

        for (String line = bin.readLine(); line != null; line = bin.readLine()) {
            for (StringTokenizer tokenizer = new StringTokenizer(line, ","); tokenizer.hasMoreTokens();) {
                railSystem.addRoute(parseRoute(tokenizer.nextToken().trim()));
            }
        }

        if (railSystem.stationCount() != expectedStationCount) {
            throw new RailSystemConfigParserException("Station count config header does not match specification.  Expected <" +
                    expectedStationCount + "> but was <" + railSystem.stationCount() + ">.");
        }

        if (railSystem.lineCount() != expectedLegCount) {
            throw new RailSystemConfigParserException("Route count config header does not match specification.  Expected <" +
                    expectedLegCount + "> but was <" + railSystem.lineCount() + ">.");
        }

        return railSystem;
    }

}
