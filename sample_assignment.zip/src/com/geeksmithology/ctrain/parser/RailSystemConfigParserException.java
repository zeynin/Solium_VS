package com.geeksmithology.ctrain.parser;

/**
 * General purpose Exception for errors that occur during parsing
 */
public class RailSystemConfigParserException extends Exception {

    public RailSystemConfigParserException(String string) {
        super(string);
    }
}
