package com.geeksmithology.ctrain;

/**
 * A line represents a station and the length of track leading to it.  
 */
public class Line {
    private Station destination;
    private int distance;

    public Line(Station destination, int distance) {
        this.destination = destination;
        this.distance = distance;
    }

    public Station getDestination() {
        return destination;
    }

    public void setDestination(Station destination) {
        this.destination = destination;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Line line = (Line) o;

        if (distance != line.distance) return false;
        if (destination != null ? !destination.equals(line.destination) : line.destination != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (destination != null ? destination.hashCode() : 0);
        result = 31 * result + distance;
        return result;
    }
}
