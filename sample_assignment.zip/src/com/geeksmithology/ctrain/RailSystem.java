package com.geeksmithology.ctrain;

import java.util.*;

/**
 * A RailSystem represents a set of stations and all of the connections between them.
 */
public class RailSystem {
    // This is used to guard against infinite loops.  A trip must reach it's destination before going this far.
    private static final int INFINITY = 9999;

    // This serves as a simple adjacency list implementation, treating the system as a graph
    private final Map<Station, Set<Line>> lines = new HashMap<Station, Set<Line>>();
    private final Set<Station> stations = new HashSet<Station>();

    /**
     * Add the provided route to the system.
     *
     * @param route The route to add.
     * @throws IllegalArgumentException if a route already exists between the given stations.
     */
    public void addRoute(Route route) {
        if (!lines.containsKey(route.getOrigin())) {
            lines.put(route.getOrigin(), new HashSet<Line>());
        }

        // While a set won't allow duplicates, we fail rather than silently ignore additional routes.
        for (Line line: lines.get(route.getOrigin())) {
            if (line.getDestination().equals(route.getDestination())) {
                throw new IllegalArgumentException("A route from " + route.getOrigin() + " to " +
                        route.getDestination() + " already exists.");
            }
        }
        lines.get(route.getOrigin()).add(new Line(route.getDestination(), route.getDistance()));

        // Not all stations are origins, and thus counting the keys doesn't return a count of all stations
        // This is more efficient than going through the entire system to find all of the stations
        stations.add(route.getOrigin());
        stations.add(route.getDestination());
    }

    /**
     * Find all possible trips between the given stations for which the total distance is less than the provided
     * maximum distance.  It is possible that the same station will be visited more than once, including the
     * destination.  Zero distance trips are ignored.
     *
     * @param origin The station from which each trip shall start.
     * @param destination The station at which each trip shall end.
     * @param maxDistance The maximum maxDistance allowable for each trip found.
     * @return A list of trips from origin to destination under the given maxDistance.
     */
    public List<Trip> findAllTripsWithinDistance(Station origin, Station destination, int maxDistance) {
        return findAllTrips(origin, destination, maxDistance);
    }

    /**
     * The number of unique stations in the system, regardless of how they are connected.
     *
     * @return The number of unique stations in this rail system.
     */
    public int stationCount() {
        return stations.size();
    }


    /**
     * Determine the total number of discrete tracks within the system.
     *
     * @return a count of every connection in the system.
     */
    public int lineCount() {
        int lineCount = 0;

        for (Set<Line> c: lines.values()) {
            lineCount += c.size();
        }

        return lineCount;
    }


    /**
     * Determine the total distance that will be travelled when using the provided trip itinerary.  The trip
     * explicitly follows the itinerary, and will throw an exception if no such trip can be completed.
     *
     * @param proposedTrip A list of stations in the order they will be visited for the trip.
     * @return The distance travelled when visiting every station in the proposed trip.
     * @throws IllegalArgumentException if the proposed trip does not exist within this system.
     */
    public int getDistanceForTrip(Station... proposedTrip) {
        int distance = 0;

        for (int i = 0; i < proposedTrip.length - 1; ++i) {
            boolean found = false;

            for (Line existing: lines.get(proposedTrip[i])) {
                if (existing.getDestination().equals(proposedTrip[i+1])) {
                    distance += existing.getDistance();
                    found = true;
                }
            }

            if (!found) {
                throw new IllegalArgumentException("No route found.");
            }
        }

        return distance;
    }

    /**
     * Find every direct trip between the given origin and destination.  A direct trip is one that will not repeat
     * stations, but instead only stop at necessary stations.
     *
     * @param origin The station from which each trip departs.
     * @param destination The station at which each trip arrives.
     * @return A list of every direct trip between the given origin and destination.
     */
    public List<Trip> findAllDirectTrips(Station origin, Station destination) {
        return findAllDirectRoutes(origin, destination, new Trip(), 0);
    }

    /**
     * Find all trips between the given stations, limiting potential trips by the number of stops.  How the number
     * of stops is treated depends on the value of the matchType.
     *
     * If matchType is EXACT, then only trips with exactly stopCount stops are included.
     * If matchType is ATLEAST, then only trips with stopCount or fewer stops are included.
     *
     * @param origin The station from which each trip departs.
     * @param destination The station at which each trip arrives.
     * @param stopCount The number of stops to use to limit the search.  Depends on matchType.
     * @param matchType Determines how the stopCount is used when finding trips.
     * @return A list of trips from origin to destination, taking stopCount into consideration.
     */
    public List<Trip> findAllTripsWithinStopCount(Station origin, Station destination, int stopCount,
                                                    MatchType matchType) {
        List<Trip> trips = findAllDirectTrips(origin, destination);

        for (Iterator i = trips.iterator(); i.hasNext();) {
            Trip trip = (Trip) i.next();
            if (matchType == MatchType.EXACT ? trip.stopCount() == stopCount : trip.stopCount() > stopCount) {
                i.remove();
            }
        }

        return trips;
    }

    /**
     * Find all direct trips between the given stations, limiting potential trips by the total distance.
     *
     * @see #findAllDirectRoutes(Station, Station, Trip, int) for explanation of direct route
     * @param origin The station from which each trip departs.
     * @param destination The station at which each trip arrives.
     * @param maxDistance Each trip will be less than this distance.
     * @return A list of direct trips from origin to destination, with a total distance less than maxDistance
     */
    public List<Trip> findAllDirectRoutesWithinDistance(Station origin, Station destination, int maxDistance) {
        List<Trip> trips = findAllDirectTrips(origin, destination);

        for (Iterator i = trips.iterator(); i.hasNext();) {
            Trip trip = (Trip) i.next();
            if (trip.totalDistance() > maxDistance) {
                i.remove();
            }
        }

        return trips;
    }

    /**
     * Find the trip between the given stations with the shortest total distance to travel.  If there is more than one
     * trip with the same distance, the first one found is returned.
     *
     * @param origin The station from which each trip begins.
     * @param destination The station at which each trip ends.
     * @return The shortest available trip between two stations.
     */
    public Trip findShortestTrip(Station origin, Station destination) {
        List<Trip> allTrips = findAllDirectTrips(origin, destination);

        Trip shortest = allTrips.get(0);
        for (int i = 1; i < allTrips.size(); ++i) {
            if (allTrips.get(i).totalDistance() < shortest.totalDistance()) {
                shortest = allTrips.get(i);
            }
        }

        return shortest;
    }


    private List<Trip> findAllTrips(Station origin, Station destination, int maxDistance) {
        // Because the method used to find all trips within a given distance can result in duplicate
        // trips being found, only return uniqe trips
        Set<Trip> trips = new HashSet<Trip>(findAllRoutes(origin, destination, new Trip(), 0, maxDistance));
        return new ArrayList<Trip>(trips);
    }

    // findAllRoutes does a breadth-first search, and allows repeated trip portions.
    // maxDistance is a required parameter, as with repeats trips could be infinite.
    private List<Trip> findAllRoutes(Station origin, Station destination, Trip trip, int distance, int maxDistance) {
        // This is a guard against infinite loops
        if (trip.totalDistance() > INFINITY) {
            return new ArrayList<Trip>();
        }

        trip = new Trip(trip);
        trip.addStop(origin, distance);

        // Base Case 1: we've reached our destination.  The additional criteria allow the route to continue
        // and allow repeated trip sections.
        if (origin.equals(destination) && trip.totalDistance() > 0 && trip.totalDistance() >= maxDistance) {
            // Because when the origin and destination are the same, we cannot cut off the trip based on maximum
            // distance without going through another trip to the destination.  We can't just count the distance
            // of the existing loop, because there is no guarantee that the pattern will repeat for a give route
            // This will result in some trips being over the maximum distance, so we truncate the trip until we're
            // within tolerance
            while (trip.totalDistance() >= maxDistance) {
                trip.truncate(destination);
            }

            List<Trip> lists = new ArrayList<Trip>();
            lists.add(trip);
            return lists;
        }

        // Base Case 2: There are no more outgoing connections, so we have a dead route.
        if (!lines.containsKey(origin)) {
            return new ArrayList<Trip>();
        }

        // Recursive Case: search all connections for the current origin
        List<Trip> trips = new ArrayList<Trip>();
        for (Line connection: lines.get(origin)) {
            if (!trip.getLastStation().equals(connection.getDestination())) {
                List<Trip> newTrips = findAllRoutes(connection.getDestination(), destination, trip,
                        connection.getDistance(), maxDistance);
                for (Trip nr: newTrips) {
                    trips.add(nr);
                }
            }
        }

        return trips;
    }

    // findAllDirectRoutes is also a breadth-first search for all routes between the two stations, but
    // does not allow repeats.
    private List<Trip> findAllDirectRoutes(Station origin, Station destination, Trip trip, int distance) {
        // This is a temporary guard against infinite loops
        if (trip.totalDistance() > INFINITY) {
            return new ArrayList<Trip>();
        }

        trip = new Trip(trip);
        trip.addStop(origin, distance);

        // Base Case 1: we've reached our destination
        if (origin.equals(destination) && trip.totalDistance() > 0) {
            List<Trip> lists = new ArrayList<Trip>();
            lists.add(trip);
            return lists;
        }

        // Base Case 2: we've run out of connections, route is dead
        if (!lines.containsKey(origin)) {
            return new ArrayList<Trip>();
        }

        // Recursive case: search each connection to the current origin
        List<Trip> trips = new ArrayList<Trip>();
        for (Line connection: lines.get(origin)) {
            if (!trip.getLastStation().equals(connection.getDestination())) {
                List<Trip> newTrips = findAllDirectRoutes(connection.getDestination(), destination, trip,
                        connection.getDistance());
                for (Trip nr: newTrips) {
                    trips.add(nr);
                }
            }
        }

        return trips;
    }
}