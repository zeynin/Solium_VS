package com.geeksmithology.solium;

import com.geeksmithology.ctrain.RailSystem;
import com.geeksmithology.ctrain.Station;
import com.geeksmithology.ctrain.MatchType;
import com.geeksmithology.ctrain.parser.RailSystemConfigParser;
import com.geeksmithology.ctrain.parser.RailSystemConfigParserException;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * Class with main method for running the inputs specified in the programming problems document
 */
public class AssignmentProblems {
    private static RailSystem railSystem;


    /**
     * Given a path to a configuration file, builds a rail system and runs the inputs specified in the
     * programming problems document.
     *
     * @param args Command line options.  index 0 is the path to a configuration file.
     * @throws IOException If there are any errors opening the configuration file.
     * @throws RailSystemConfigParserException If the provided configuration file is malformed.
     */
    public static void main(String... args) throws IOException, RailSystemConfigParserException {
        if (args.length == 0 || args.length > 2) {
            System.err.println();
            System.err.println("AssignmentProblems requires one argument, the name of the config file.");
            System.err.println();
            System.err.println("Example: java com.geeksmithologyl.solium.AssignmentProblem config.txt");
            System.err.println();
            System.exit(1);
        }

        File config = new File(args[0]);
        railSystem = new RailSystemConfigParser().parseSystemConfiguration(new FileReader(config));

        distanceQuestions();
        questionSix();
        questionSeven();
        questionEight();
        questionNine();
        questionTen();
    }

    private static void distanceQuestions() {
        Station[][] routes = new Station[][]{
                {new Station("A"), new Station("B"), new Station("C")},
                {new Station("A"), new Station("D")},
                {new Station("A"), new Station("D"), new Station("C")},
                {new Station("A"), new Station("E"), new Station("B"), new Station("C"), new Station("D")},
                {new Station("A"), new Station("E"), new Station("D")}
        };
        for (int i = 0; i < routes.length; ++i) {
            System.out.print("Output #" + (i + 1) + ": ");
            try {
                System.out.println(railSystem.getDistanceForTrip(routes[i]));
            } catch (IllegalArgumentException e) {
                System.out.println("NO ROUTE FOUND!");
            }
        }
    }

    private static void questionSix() {
        System.out.print("Output #6: ");
        System.out.println(railSystem.findAllTripsWithinStopCount(
                new Station("C"), new Station("C"), 3, MatchType.ATLEAST
        ).size());
    }

    private static void questionSeven() {
        System.out.print("Output #7: ");
        System.out.println(railSystem.findAllTripsWithinStopCount(
                new Station("A"), new Station("C"), 4, MatchType.EXACT
        ).size());
    }

    private static void questionEight() {
        System.out.print("Output #8: ");
        System.out.println(railSystem.findShortestTrip(new Station("A"), new Station("C")).totalDistance());
    }

    private static void questionNine() {
        System.out.print("Output #7: ");
        System.out.println(railSystem.findShortestTrip(new Station("B"), new Station("B")).totalDistance());
    }

    private static void questionTen() {
        System.out.print("Output #10: ");
        System.out.println(railSystem.findAllTripsWithinDistance(new Station("C"), new Station("C"), 30).size());
    }
}

