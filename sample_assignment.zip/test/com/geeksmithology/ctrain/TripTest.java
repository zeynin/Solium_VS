package com.geeksmithology.ctrain;

import org.junit.Test;
import static org.junit.Assert.*;
import com.geeksmithology.ctrain.Station;
import com.geeksmithology.ctrain.Trip;

public class TripTest {    
    @Test
    public void shouldReturnCorrectStationCount() {
        Trip trip = new Trip();
        trip.addStop(new Station("A"), 4);
        trip.addStop(new Station("B"), 5);
        assertEquals(2, trip.stationCount());
    }

    @Test
    public void shouldReturnStopCount() {
        Trip trip = new Trip();
        trip.addStop(new Station("A"), 5);
        trip.addStop(new Station("B"), 4);
        trip.addStop(new Station("C"), 5);
        assertEquals(2, trip.stopCount());

    }

    @Test
    public void shouldGetLastStation() {
        Trip trip = new Trip();
        trip.addStop(new Station("A"), 4);
        trip.addStop(new Station("B"), 3);
        trip.addStop(new Station("C"), 3);
        assertEquals(new Station("C"), trip.getLastStation());
    }

    @Test
    public void shouldCalculateZeroTotalDistance() {
        assertEquals(0, new Trip().totalDistance());
    }

    @Test
    public void shouldCalculateNonZeroTotalRouteDistance() {
        Trip trip = new Trip();
        trip.addStop(new Station("A"), 5);
        trip.addStop(new Station("B"), 6);
        trip.addStop(new Station("C"), 3);
        assertEquals(14, trip.totalDistance());
    }

    @Test
    public void shouldGetTrip() {
        Trip trip = new Trip();
        trip.addStop(new Station("A"), 0);
        trip.addStop(new Station("B"), 5);
        trip.addStop(new Station("C"), 6);
        assertEquals(2, trip.stopCount());
    }
}
