package com.geeksmithology.ctrain.parser;

import org.junit.Test;
import static org.junit.Assert.*;
import com.geeksmithology.ctrain.Route;
import com.geeksmithology.ctrain.Station;
import com.geeksmithology.ctrain.RailSystem;

import java.io.*;


public class SystemParserTest {
    private final RailSystemConfigParser parser = new RailSystemConfigParser();

    @Test (expected = RailSystemConfigParserException.class)
    public void shouldNotAllowMalformedHeader() throws IOException, RailSystemConfigParserException {
        String config = "4,C";
        parser.parseSystemConfiguration(new StringReader(config));
    }

    @Test (expected = RailSystemConfigParserException.class)
    public void shouldThrowExceptionOnIncorrectStationCountInHeader() throws IOException, RailSystemConfigParserException {
        StringBuffer config = new StringBuffer("1,5").append("\n");
        config.append("AB5");
        parser.parseSystemConfiguration(new StringReader(config.toString()));
    }

    @Test (expected = RailSystemConfigParserException.class)
    public void shouldThrowExceptionOnIncorrectLegCountInHeader() throws IOException, RailSystemConfigParserException {
        StringBuffer config = new StringBuffer("2,2");
        config.append("AB5");
        parser.parseSystemConfiguration(new StringReader(config.toString()));
    }

    @Test (expected = RailSystemConfigParserException.class)
    public void shouldNotAllowShortShortDescription() throws RailSystemConfigParserException {
        parser.parseRoute("AA");
    }

    @Test (expected = RailSystemConfigParserException.class)
    public void shouldNotAllowLongDescription() throws RailSystemConfigParserException {
        parser.parseRoute("ABA5");
    }

    @Test (expected = RailSystemConfigParserException.class)
    public void shouldNotAllowMalformedDescription() throws RailSystemConfigParserException {
        parser.parseRoute("A5B");
    }

    @Test (expected = RailSystemConfigParserException.class)
    public void shouldNotAllowIllegalCharacterInDescription() throws RailSystemConfigParserException {
        parser.parseRoute("A*B");
    }

    @Test (expected = RailSystemConfigParserException.class)
    public void shouldNotAllowLettersOverMInDescription() throws RailSystemConfigParserException {
        parser.parseRoute("AN5");
    }

    @Test
    public void shouldParseProperlyFormattedDescription() throws RailSystemConfigParserException {
        Route expected = new Route(new Station("A"), new Station("B"), 5);
        assertEquals(expected, parser.parseRoute("AB5"));
    }

    @Test
    public void shouldParseFile() throws IOException, RailSystemConfigParserException {
        StringBuffer file = new StringBuffer("3,3").append("\n");
        file.append("AB5,BC5,CA6");

        Reader in = new StringReader(file.toString());
        RailSystem service = parser.parseSystemConfiguration(in);

        assertEquals(3, service.stationCount());
        assertEquals(3, service.lineCount());
        assertEquals(5, service.getDistanceForTrip(new Station("A"), new Station("B")));
        assertEquals(5, service.getDistanceForTrip(new Station("B"), new Station("C")));
        assertEquals(6, service.getDistanceForTrip(new Station("C"), new Station("A")));
    }
}
