package com.geeksmithology.ctrain;

import org.junit.Test;

public class RouteTest {
    @Test (expected = IllegalArgumentException.class)
    public void shouldNotAllowSameOriginAndDestination() {
        new Route(new Station("A"), new Station("A"), 7);
    }

    @Test (expected = IllegalArgumentException.class)
    public void shouldNotAllowZeroDistance() {
        new Route(new Station("A"), new Station("B"), 0);
    }

    @Test (expected = IllegalArgumentException.class)
    public void shouldNotAllowDistanceOverTen() {
        new Route(new Station("A"), new Station("B"), 10);
    }
}
