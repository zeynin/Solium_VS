package com.geeksmithology.ctrain;

import org.junit.Test;

public class StationTest {
    @Test (expected = IllegalArgumentException.class)
    public void shouldNotAllowLetterAfterMForName() {
        new Station("N");
    }
}
