package com.geeksmithology.ctrain;

import org.junit.Test;
import static org.junit.Assert.*;

import java.util.List;
import java.util.Collections;
import java.util.Comparator;

public class RailSystemTest {
    @Test (expected = IllegalArgumentException.class)
    public void shouldNotAllowSameRouteToBeAddedTwice() {
        RailSystem railSystem = new RailSystem();
        railSystem.addRoute(new Route(new Station("A"), new Station("B"), 5));
        railSystem.addRoute(new Route(new Station("A"), new Station("B"), 6));
    }

    @Test
    public void shouldReturnStationCount() {
        RailSystem system = new RailSystem();
        system.addRoute(new Route(new Station("A"), new Station("B"), 5));
        system.addRoute(new Route(new Station("B"), new Station("C"), 6));
        assertEquals(3, system.stationCount());
    }

    @Test
    public void shouldReturnConnectionCount() {
        RailSystem system = new RailSystem();
        system.addRoute(new Route(new Station("A"), new Station("B"), 5));
        system.addRoute(new Route(new Station("B"), new Station("C"), 6));
        assertEquals(2, system.lineCount());
    }

    @Test
    public void shouldFindDirectDistanceForTwoStops() {
        RailSystem system = new RailSystem();
        system.addRoute(new Route(new Station("A"), new Station("B"), 5));
        system.addRoute(new Route(new Station("B"), new Station("C"), 6));
        assertEquals(11, system.getDistanceForTrip(new Station("A"), new Station("B"), new Station("C")));
    }

    @Test
    public void shouldFindDirectDistanceForThreeStops() {
        RailSystem system = new RailSystem();
        system.addRoute(new Route(new Station("A"), new Station("B"), 5));
        system.addRoute(new Route(new Station("B"), new Station("C"), 6));
        system.addRoute(new Route(new Station("C"), new Station("D"), 5));
        assertEquals(16, system.getDistanceForTrip(new Station("A"), new Station("B"), new Station("C"),
                new Station("D")));
    }

    @Test(expected=IllegalArgumentException.class)
    public void shouldNotFindNotExistentDirectRoute() {
        RailSystem system = new RailSystem();
        system.addRoute(new Route(new Station("A"), new Station("B"), 5));
        system.addRoute(new Route(new Station("B"), new Station("C"), 6));
        system.getDistanceForTrip(new Station("A"), new Station("C"));

    }

    @Test
    public void shouldFindAllRoutes() {
        RailSystem system = new RailSystem();
        system.addRoute(new Route(new Station("A"), new Station("B"), 5));
        system.addRoute(new Route(new Station("B"), new Station("C"), 6));
        system.addRoute(new Route(new Station("C"), new Station("D"), 5));
        system.addRoute(new Route(new Station("A"), new Station("C"), 3));
        system.addRoute(new Route(new Station("A"), new Station("E"), 8));
        system.addRoute(new Route(new Station("D"), new Station("C"), 7));
        List<Trip> trips = system.findAllDirectTrips(new Station("A"), new Station("C"));

        // Trips need to be in correct order for assertions to be valid, and method does not guarantee order
        Collections.sort(trips, new Comparator<Trip>() {
            public int compare(Trip o, Trip o1) {
                return ((Integer) o.totalDistance()).compareTo(o1.totalDistance());
            }

        });

        assertEquals(2, trips.size());

        Trip trip = trips.get(0);
        Station[] expected = new Station[]{new Station("A"), new Station("C")};

        assertEquals(3, trip.totalDistance());
        assertEquals(2, trip.stationCount());
        assertArrayEquals(expected, trip.stations().toArray(new Station[]{}));

        trip = trips.get(1);
        expected = new Station[]{new Station("A"), new Station("B"), new Station("C")};

        assertEquals(11, trip.totalDistance());
        assertEquals(3, trip.stationCount());
        assertArrayEquals(expected, trip.stations().toArray(new Station[]{}));
    }

    @Test
    public void shouldFindRoutesWithSameOriginAndDestination() {
        RailSystem railSystem = new RailSystem();
        railSystem.addRoute(new Route(new Station("A"), new Station("B"), 5));
        railSystem.addRoute(new Route(new Station("B"), new Station("A"), 5));
        List<Trip> trips = railSystem.findAllDirectTrips(new Station("A"), new Station("A"));
        Trip trip = trips.get(0);
        assertEquals(10, trip.totalDistance());
    }

    @Test
    public void shouldFindMultipleRoutesWithSameOriginAndDestination() {
        RailSystem railSystem = new RailSystem();
        railSystem.addRoute(new Route(new Station("A"), new Station("B"), 6));
        railSystem.addRoute(new Route(new Station("B"), new Station("A"), 8));
        railSystem.addRoute(new Route(new Station("A"), new Station("C"), 5));
        railSystem.addRoute(new Route(new Station("C"), new Station("D"), 4));
        railSystem.addRoute(new Route(new Station("D"), new Station("A"), 9));
        railSystem.addRoute(new Route(new Station("C"), new Station("A"), 4));
        List<Trip> trips = railSystem.findAllDirectTrips(new Station("A"), new Station("A"));
        assertEquals(3, trips.size());
    }

    @Test
    public void shouldFindAllRoutesWithGivenNumberOfStops() {
        RailSystem railSystem = new RailSystem();
        railSystem.addRoute(new Route(new Station("A"), new Station("B"), 5));
        railSystem.addRoute(new Route(new Station("B"), new Station("C"), 5));
        railSystem.addRoute(new Route(new Station("C"), new Station("A"), 6));
        railSystem.addRoute(new Route(new Station("B"), new Station("A"), 8));
        List<Trip> trips = railSystem.findAllTripsWithinStopCount(
                new Station("A"), new Station("A"), 2, MatchType.EXACT);
        assertEquals(1, trips.size());
    }

    @Test
    public void shouldFindAllRoutesWithLessThenOrEqualToGivenNumberOfStops() {
        RailSystem railSystem = new RailSystem();

        railSystem.addRoute(new Route(new Station("A"), new Station("B"), 5));
        railSystem.addRoute(new Route(new Station("B"), new Station("C"), 5));
        railSystem.addRoute(new Route(new Station("C"), new Station("A"), 6));

        railSystem.addRoute(new Route(new Station("A"), new Station("D"), 3));
        railSystem.addRoute(new Route(new Station("D"), new Station("A"), 6));

        railSystem.addRoute(new Route(new Station("A"), new Station("E"), 1));
        railSystem.addRoute(new Route(new Station("E"), new Station("A"), 4));

        railSystem.addRoute(new Route(new Station("A"), new Station("F"), 4));
        railSystem.addRoute(new Route(new Station("F"), new Station("G"), 8));
        railSystem.addRoute(new Route(new Station("G"), new Station("H"), 9));
        railSystem.addRoute(new Route(new Station("H"), new Station("A"), 4));

        List<Trip> trips =
                railSystem.findAllTripsWithinStopCount(new Station("A"), new Station("A"), 3, MatchType.ATLEAST);
        assertEquals(3, trips.size());
    }

    @Test
    public void shouldFindAllRoutesWithLessThanOrEqualToGivenMaximumDistance() {
        RailSystem railSystem = new RailSystem();

        railSystem.addRoute(new Route(new Station("A"), new Station("B"), 6));
        railSystem.addRoute(new Route(new Station("B"), new Station("A"), 8));

        railSystem.addRoute(new Route(new Station("A"), new Station("C"), 3));
        railSystem.addRoute(new Route(new Station("C"), new Station("D"), 3));
        railSystem.addRoute(new Route(new Station("D"), new Station("A"), 3));

        railSystem.addRoute(new Route(new Station("A"), new Station("E"), 4));
        railSystem.addRoute(new Route(new Station("E"), new Station("A"), 6));

        List<Trip> trips = railSystem.findAllDirectRoutesWithinDistance(new Station("A"), new Station("A"), 10);
        assertEquals(2, trips.size());
    }

    @Test
    public void shouldWorkWithRepeats() {
        RailSystem railSystem = new RailSystem();

        railSystem.addRoute(new Route(new Station("A"), new Station("B"), 3));
        railSystem.addRoute(new Route(new Station("B"), new Station("A"), 4));
        railSystem.addRoute(new Route(new Station("B"), new Station("E"), 5));
        railSystem.addRoute(new Route(new Station("E"), new Station("A"), 4));

        List<Trip> trips = railSystem.findAllTripsWithinDistance(new Station("A"), new Station("A"), 30);
        assertEquals(8, trips.size());
    }


    @Test
    public void shouldFindShortestRoute() {
        RailSystem railSystem = new RailSystem();
        railSystem.addRoute(new Route(new Station("A"), new Station("B"), 5));
        railSystem.addRoute(new Route(new Station("B"), new Station("C"), 6));
        railSystem.addRoute(new Route(new Station("A"), new Station("D"), 6));
        railSystem.addRoute(new Route(new Station("D"), new Station("C"), 7));
        railSystem.addRoute(new Route(new Station("B"), new Station("E"), 1));
        railSystem.addRoute(new Route(new Station("E"), new Station("F"), 1));
        railSystem.addRoute(new Route(new Station("F"), new Station("C"), 1));
        Trip trip = railSystem.findShortestTrip(new Station("A"), new Station("C"));
        assertEquals(8, trip.totalDistance());
        assertEquals(5, trip.stationCount());
        
        Station[] expected = new Station[]{
                new Station("A"), new Station("B"), new Station("E"), new Station("F"), new Station("C")};
        assertArrayEquals(expected, trip.stations().toArray(new Station[]{}));
    }
}
