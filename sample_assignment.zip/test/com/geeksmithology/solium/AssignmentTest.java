package com.geeksmithology.solium;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import com.geeksmithology.ctrain.RailSystem;
import com.geeksmithology.ctrain.Route;
import com.geeksmithology.ctrain.Station;
import com.geeksmithology.ctrain.MatchType;

/**
 * This test file ensures that all of the assignment inputs evaluate correctly throughout development
 */
public class AssignmentTest {
    private RailSystem railSystem;

    @Before
    public void setUp() {
        railSystem = new RailSystem();

        railSystem.addRoute(new Route(new Station("A"), new Station("B"), 5));
        railSystem.addRoute(new Route(new Station("B"), new Station("C"), 4));
        railSystem.addRoute(new Route(new Station("C"), new Station("D"), 8));
        railSystem.addRoute(new Route(new Station("D"), new Station("C"), 8));
        railSystem.addRoute(new Route(new Station("D"), new Station("E"), 6));
        railSystem.addRoute(new Route(new Station("A"), new Station("D"), 5));
        railSystem.addRoute(new Route(new Station("C"), new Station("E"), 2));
        railSystem.addRoute(new Route(new Station("E"), new Station("B"), 3));
        railSystem.addRoute(new Route(new Station("A"), new Station("E"), 7));
    }

    @Test
    public void testCase1() {
        assertEquals(9, railSystem.getDistanceForTrip(new Station("A"), new Station("B"), new Station("C")));
    }

    @Test
    public void testCase2() {
        assertEquals(5, railSystem.getDistanceForTrip(new Station("A"), new Station("D")));
    }

    @Test
    public void testCase3() {
        assertEquals(13, railSystem.getDistanceForTrip(new Station("A"), new Station("D"), new Station("C")));
    }

    @Test
    public void testCase4() {
        assertEquals(22, railSystem.getDistanceForTrip(new Station("A"), new Station("E"), new Station("B"),
                new Station("C"), new Station("D")));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCase5() {
        railSystem.getDistanceForTrip(new Station("A"), new Station("E"), new Station("D"));
    }

    @Test
    public void testCase6() {
        assertEquals(2, railSystem.findAllTripsWithinStopCount(
                new Station("C"), new Station("C"), 3, MatchType.ATLEAST).size());
    }

    @Test
    public void testCase7() {
        assertEquals(3, railSystem.findAllTripsWithinStopCount(
                new Station("A"), new Station("C"), 4, MatchType.EXACT).size());
    }

    @Test
    public void testCase8() {
        assertEquals(9, railSystem.findShortestTrip(new Station("A"), new Station("C")).totalDistance());
    }

    @Test
    public void testCase9() {
        assertEquals(9, railSystem.findShortestTrip(new Station("B"), new Station("B")).totalDistance());
    }

    @Test
    public void testCase10() {
        assertEquals(7, railSystem.findAllTripsWithinDistance(new Station("C"), new Station("C"), 30).size());
    }
}

